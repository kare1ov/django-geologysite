from django.apps import AppConfig


class GeologysiteConfig(AppConfig):
    name = 'geologysite'
