from django.contrib import admin
from.models import MineralModel, RockModel, Article


admin.site.register(MineralModel)
admin.site.register(RockModel)
admin.site.register(Article)
